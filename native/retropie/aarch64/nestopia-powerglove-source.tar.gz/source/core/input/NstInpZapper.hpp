////////////////////////////////////////////////////////////////////////////////////////
//
// Nestopia - NES/Famicom emulator written in C++
//
// Copyright (C) 2003-2008 Martin Freij
//
// This file is part of Nestopia.
//
// Nestopia is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// Nestopia is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Nestopia; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
////////////////////////////////////////////////////////////////////////////////////////

#ifndef NST_INPUT_ZAPPER_H
#define NST_INPUT_ZAPPER_H

namespace Nes
{
	namespace Core
	{
		class Ppu;

		namespace Input
		{
			class Zapper : public Device
			{
			public:

				Zapper(const Cpu&,Ppu&);

			private:

				void Reset();
				void Initialize(bool);
				uint Poll();
				void Poke(uint);
				uint Peek(uint);
				uint GetHitPixel() const;
				void LoadState(State::Loader&,dword);
				void SaveState(State::Saver&,byte) const;

				enum
				{
					PHOSPHOR_DECAY = 384,
					LIGHT_SENSOR = 0x40
				};

				ibool arcade;
				uint stream;
				uint shifter;
				uint pos;
				uint fire;
				Ppu& ppu;

				static const byte lightMap[Video::Screen::PALETTE];

			public:

				static uint GetLightMap(uint pixel)
				{
					NST_ASSERT( pixel < Video::Screen::PALETTE );
					return lightMap[pixel];
				}
			};
		}
	}
}

#endif
