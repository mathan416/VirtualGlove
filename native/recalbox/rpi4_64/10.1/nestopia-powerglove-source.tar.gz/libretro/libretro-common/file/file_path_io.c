/* Copyright  (C) 2010-2020 The RetroArch team
 *
 * ---------------------------------------------------------------------------------------
 * The following license statement only applies to this file (file_path_io.c).
 * ---------------------------------------------------------------------------------------
 *
 * Permission is hereby granted, free of charge,
 * to any person obtaining a copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
 * and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <sys/stat.h>

/* MinGW's <sys/stat.h> defines stat (and in some configs mkdir) as
 * function-like macros that map to _stat64/_stati64/_mkdir.  This must
 * be undone BEFORE including libretro.h below: otherwise the macro
 * rewrites the struct member name in the retro_vfs_interface definition
 * (retro_vfs_stat_t stat -> _stat64), and then the use sites
 * vfs_iface->stat / vfs_iface->mkdir no longer match it, breaking the
 * Windows build.  The POSIX functions are still reachable via their
 * real names where this TU needs them (it doesn't call stat()/mkdir()
 * directly; all I/O goes through the VFS *_impl callbacks). */
#ifdef stat
#undef stat
#endif
#ifdef mkdir
#undef mkdir
#endif

#include <boolean.h>
#include <file/file_path.h>
#include <compat/strl.h>
#include <compat/posix_string.h>
#include <retro_miscellaneous.h>
#define VFS_FRONTEND
#include <vfs/vfs_implementation.h>

#ifdef _WIN32
#include <direct.h>
#else
#include <unistd.h> /* stat() is defined here */
#endif

/* <direct.h> (MinGW, included just above) can re-establish the mkdir
 * macro after the earlier #undef, so drop it again here before the use
 * site below.  Same rationale for stat, defensively. */
#ifdef stat
#undef stat
#endif
#ifdef mkdir
#undef mkdir
#endif

/* TODO/FIXME - globals */
static retro_vfs_stat_t path_stat32_cb = retro_vfs_stat_impl;
static retro_vfs_stat_64_t path_stat64_cb = retro_vfs_stat_64_impl;
static retro_vfs_mkdir_t path_mkdir_cb = retro_vfs_mkdir_impl;

void path_vfs_init(const struct retro_vfs_interface_info* vfs_info)
{
   const struct retro_vfs_interface* 
      vfs_iface           = vfs_info->iface;

   path_stat32_cb         = retro_vfs_stat_impl;
   path_stat64_cb         = retro_vfs_stat_64_impl;
   path_mkdir_cb          = retro_vfs_mkdir_impl;

   if (vfs_info->required_interface_version < PATH_REQUIRED_VFS_VERSION || !vfs_iface)
      return;

   path_stat32_cb         = vfs_iface->stat;
   path_mkdir_cb          = vfs_iface->mkdir;

   if (vfs_info->required_interface_version >= STAT64_REQUIRED_VFS_VERSION)
      path_stat64_cb = vfs_iface->stat_64;
   else
      path_stat64_cb = NULL;
}

int path_stat(const char *path)
{
   /* Use 64‑bit stat if available, else fallback */
   return path_stat64_cb ? path_stat64_cb(path, NULL) : path_stat32_cb(path, NULL);
}

/**
 * path_is_directory:
 * @path               : path
 *
 * Checks if path is a directory.
 *
 * @return true if path is a directory, otherwise false.
 */
bool path_is_directory(const char *path)
{
   if (path_stat64_cb)
      return (path_stat64_cb(path, NULL) & RETRO_VFS_STAT_IS_DIRECTORY) != 0;
   return (path_stat32_cb(path, NULL) & RETRO_VFS_STAT_IS_DIRECTORY) != 0;
}

bool path_is_character_special(const char *path)
{
   if (path_stat64_cb)
      return (path_stat64_cb(path, NULL) & RETRO_VFS_STAT_IS_CHARACTER_SPECIAL) != 0;
   return (path_stat32_cb(path, NULL) & RETRO_VFS_STAT_IS_CHARACTER_SPECIAL) != 0;
}

bool path_is_valid(const char *path)
{
   if (path_stat64_cb)
      return (path_stat64_cb(path, NULL) & RETRO_VFS_STAT_IS_VALID) != 0;
   return (path_stat32_cb(path, NULL) & RETRO_VFS_STAT_IS_VALID) != 0;
}

int64_t path_get_size(const char *path)
{
   int64_t filesize = 0;
   int32_t filesize32 = 0;

   if (path_stat64_cb && path_stat64_cb(path, &filesize) != 0)
      return filesize;

   /* Fallback: 32-bit stat */
   if (path_stat32_cb && path_stat32_cb(path, &filesize32) != 0)
      return (int64_t)filesize32;

   return -1;
}

/**
 * path_mkdir:
 * @dir                : directory
 *
 * Create directory on filesystem.
 * 
 * Recursive function.
 *
 * @return true if directory could be created, otherwise false.
 **/
bool path_mkdir(const char *dir)
{
   bool norecurse     = false;
   char     *basedir  = NULL;

   if (!(dir && *dir))
      return false;

   /* Nothing to do if it is already there.
    *
    * Without this the common case - which for archive extraction is
    * every member after the first in a given directory - still costs
    * a strdup, a path_parent_dir, a strcmp, a stat of the parent, a
    * mkdir that is guaranteed to fail with EEXIST, and then a stat of
    * the leaf to interpret that failure.  Two directory probes and a
    * doomed syscall to answer a question one probe answers.  On Win32
    * each of those probes is a UTF-16 conversion allocation plus both
    * GetFileAttributesW and _wstat64, so the saving there is larger
    * than the syscall count suggests.
    *
    * This is not a shortcut around the slow path's result: the slow
    * path already returns true for an existing directory, by way of
    * the mkdir -> -2 -> path_is_directory sequence at the bottom.  The
    * one behavioural difference is at a filesystem root ("/", "C:\"),
    * where path_parent_dir empties the string and the !*basedir guard
    * below returns false today; such a directory does exist, so
    * reporting true for it is the correction, not a regression. */
   if (path_is_directory(dir))
      return true;

   /* Use heap. Real chance of stack 
    * overflow if we recurse too hard. */
   if (!(basedir = strdup(dir)))
      return false;

   path_parent_dir(basedir, strlen(basedir));

   if (!*basedir || !strcmp(basedir, dir))
   {
      free(basedir);
      return false;
   }

   if (     path_is_directory(basedir)
         || path_mkdir(basedir))
      norecurse = true;

   free(basedir);

   if (norecurse)
   {
      int ret = path_mkdir_cb(dir);

      /* Don't treat this as an error. */
      if (ret == -2 && path_is_directory(dir))
         return true;
      else if (ret == 0)
         return true;
   }
   return false;
}
