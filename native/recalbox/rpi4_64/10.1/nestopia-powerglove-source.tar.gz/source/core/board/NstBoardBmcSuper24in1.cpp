////////////////////////////////////////////////////////////////////////////////////////
//
// Nestopia - NES/Famicom emulator written in C++
//
// Copyright (C) 2003-2008 Martin Freij
//
// This file is part of Nestopia.
//
// Nestopia is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// Nestopia is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Nestopia; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
////////////////////////////////////////////////////////////////////////////////////////

#include "NstBoard.hpp"
#include "NstBoardMmc3.hpp"
#include "NstBoardBmcSuper24in1.hpp"

namespace Nes
{
	namespace Core
	{
		namespace Boards
		{
			namespace Bmc
			{
				void Super24in1::SubReset(const bool hard)
				{
					if (hard)
					{
						exRegs[0] = 0x24;
						exRegs[1] = 0x9F;
						exRegs[2] = 0x00;
						exRegs[3] = 0x00;
					}

					Mmc3::SubReset( hard );

					/* The chipset decodes $E003, not the MMC3's $E001. Writes
					 * with A1 set reach no register, which some multicarts rely
					 * on - $9FFF must not act as a bank data write.
					*/
					for (uint i=0x0002; i < 0x2000; i += 0x4)
					{
						Map( 0x8000 + i, 0x8001 + i, NOP_POKE );
						Map( 0xA000 + i, 0xA001 + i, NOP_POKE );
						Map( 0xC000 + i, 0xC001 + i, NOP_POKE );
						Map( 0xE000 + i, 0xE001 + i, NOP_POKE );
					}

					Map( 0x5000U, 0x5FFFU, &Super24in1::Poke_5000 );
				}

				void Super24in1::SubLoad(State::Loader& state,const dword baseChunk)
				{
					if (baseChunk == AsciiId<'B','2','4'>::V)
					{
						while (const dword chunk = state.Begin())
						{
							if (chunk == AsciiId<'R','E','G'>::V)
							{
								State::Loader::Data<3> data( state );

								exRegs[0] = data[0];
								exRegs[1] = data[1];
								exRegs[2] = data[2];
								exRegs[3] = 0x00;
							}

							state.End();
						}
					}
					else
					{
						Mmc3::SubLoad( state, baseChunk );
					}
				}

				void Super24in1::SubSave(State::Saver& state) const
				{
					Mmc3::SubSave( state );

					const byte data[3] =
					{
						static_cast<byte>(exRegs[0]),
						static_cast<byte>(exRegs[1]),
						static_cast<byte>(exRegs[2])
					};

					state.Begin( AsciiId<'B','2','4'>::V ).Begin( AsciiId<'R','E','G'>::V ).Write( data ).End().End();
				}

				/* The registers answer across $5000-$5FFF, selected by the low
				 * two address bits and gated by one bit chosen with a solder
				 * pad. Setting zero - the $5013 mask - is the one that works for
				 * any image, and it still covers the $5FFx writes that carts
				 * wired for other settings use, since those have every pad bit
				 * set.
				*/
				NES_POKE_AD(Super24in1,5000)
				{
					if (!(address & SOLDER_PAD))
						return;

					const uint index = address & 0x3;

					if (exRegs[index] == data)
						return;

					exRegs[index] = data;

					switch (index)
					{
						case 0:

							Mmc3::UpdateChr();
							Mmc3::UpdatePrg();
							break;

						case 1:

							Mmc3::UpdatePrg();
							break;

						case 2:

							Mmc3::UpdateChr();
							break;
					}
				}

				void NST_FASTCALL Super24in1::UpdatePrg(uint address,uint bank)
				{
					static const byte masks[8] = {0x3F,0x1F,0xF,0x1,0x3,0x0,0x0,0x0};

					prg.SwapBank<SIZE_8K>( address, (exRegs[1] << 1) | (bank & masks[exRegs[0] & 0x7]) );
				}

				void NST_FASTCALL Super24in1::UpdateChr(uint address,uint bank) const
				{
					chr.Source( exRegs[0] >> 5 & 0x1 ).SwapBank<SIZE_1K>( address, (exRegs[2] << 3 & 0xF00) | bank );
				}
			}
		}
	}
}
