////////////////////////////////////////////////////////////////////////////////////////
//
// Nestopia - NES/Famicom emulator written in C++
//
// Copyright (C) 2003-2008 Martin Freij
//
// This file is part of Nestopia.
//
// Nestopia is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// Nestopia is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Nestopia; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
////////////////////////////////////////////////////////////////////////////////////////

#include "NstBoard.hpp"
#include "NstBoardSachenTca01.hpp"

namespace Nes
{
	namespace Core
	{
		namespace Boards
		{
			namespace Sachen
			{
				/*void Tca01::SubReset(bool)
				{
					for (uint i=0x4100; i < 0x6000; i += 0x200)
						Map( i + 0x00, i + 0xFF, &Tca01::Peek_4100 );
				}*/
				// shalma's fix for Dancing Blocks (Sachen)
				void Tca01::SubReset(bool hard)
				{
					for (uint i=0x4100; i < 0x6000; i += 0x200)
						Map( i + 0x00, i + 0xFF, &Tca01::Peek_4100 );

					if (hard)
					{
						//FCEUmm (cah4e3) - random boot fix
						for (int lcv = 0; lcv < 0x800; lcv++)
						{
							cpu.Poke(lcv, (lcv & 4) ? 0x7f : 0x00);
						}

						// Nestopia default
						cpu.Poke(0x08, 0xF7);
						cpu.Poke(0x09, 0xEF);
						cpu.Poke(0x0a, 0xDF);
						cpu.Poke(0x0b, 0xBF);
					}
				}

				NES_PEEK_A(Tca01,4100)
				{
					return (~address & 0x3F) | 0x40;
				}
			}
		}
	}
}
